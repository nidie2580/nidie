import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'
import { readFileSync, existsSync } from 'node:fs'

const __filename = fileURLToPath(import.meta.url)
const __dirname = dirname(__filename)
const PKG_PATH = join(__dirname, '..', '..', 'package.json')

export default {
  key: 'nidie-plugin-manager',
  name: 'nidie插件管理器配置',
  desc: '插件管理器的默认插件源与行为配置',

  load() {
    let pkg = {}
    if (existsSync(PKG_PATH)) {
      try { pkg = JSON.parse(readFileSync(PKG_PATH, 'utf-8')) } catch {}
    }
    return {
      version: pkg.version || '1.0.0',
      autoUpdate: false,
      defaultBranch: 'main',
      defaultSources: [
        {
          name: 'nidie官方源',
          url: 'https://github.com/nidie2580/nidie-plugins',
          desc: '由 nidie2580 维护的官方插件仓库'
        },
        {
          name: 'XRK-Yunzai',
          url: 'https://github.com/sunflowermm/XRK-Yunzai',
          desc: 'XRK-Yunzai 主项目（含 system-plugin）'
        },
        {
          name: 'XRK-Yunzai Gitee',
          url: 'https://gitee.com/xrkseek/XRK-Yunzai',
          desc: 'XRK-Yunzai Gitee 镜像（国内访问快）'
        }
      ]
    }
  }
}
