# nidie-plugin-manager

🧰 **nidie 插件管理器** - 专为 [XRK-Yunzai](https://gitcode.com/xrkseek/XRK-Yunzai) 设计的插件管理系统。一键安装、更新、卸载、管理所有插件。

## ✨ 功能特性

- ✅ **插件安装** - 支持 GitHub 短名、完整 URL 等多种格式
- ✅ **插件更新** - 单独更新或批量更新所有 Git 插件
- ✅ **插件卸载** - 安全卸载（自动备份，1分钟后清理）
- ✅ **插件列表** - 查看所有已安装插件及状态
- ✅ **插件信息** - 查看版本、提交记录、能力、依赖等详情
- ✅ **启用 / 禁用** - 标记插件启用状态（重启生效）
- ✅ **插件源管理** - 添加、删除、列出第三方插件源
- ✅ **插件搜索** - 关键词搜索已安装插件和配置源
- ✅ **依赖安装** - 自动识别 pnpm workspace 并安装插件依赖
- ✅ **数据持久化** - 安装信息本地 JSON 持久化

## 📦 安装方法

### 方式一：Git 安装（推荐）

在 XRK-Yunzai 根目录执行：

```bash
git clone --depth=1 https://github.com/nidie2580/nidie.git ./plugins/nidie-plugin-manager/
```

若您的仓库结构中插件管理器是一个子目录，请将该子目录内容复制到 `./plugins/nidie-plugin-manager/`。

### 方式二：手动安装

1. 下载本仓库所有文件
2. 复制到 XRK-Yunzai 的 `plugins/nidie-plugin-manager/` 目录
3. 确保目录结构如下：

```
XRK-Yunzai/
└── plugins/
    └── nidie-plugin-manager/
        ├── index.js
        ├── package.json
        ├── .gitignore
        ├── plugin/
        │   └── manager.js
        ├── lib/
        │   ├── store.js
        │   ├── git-utils.js
        │   └── plugin-utils.js
        ├── commonconfig/
        │   └── pm-defaults.js
        └── data/
            └── .gitkeep
```

### 安装依赖

如果项目使用 pnpm workspaces：

```bash
# 在 XRK-Yunzai 根目录
pnpm install
```

## 🚀 使用方法

> 📌 **所有命令需主人（master）权限**，`#` 前缀可选。

### 📖 帮助

```
#插件帮助
#pm 帮助
插件帮助
```

### 📋 插件列表

```
插件列表           # 列出所有已安装插件
```

### ⬇️ 安装插件

支持以下三种输入格式：

```bash
# 1. 完整 Git 地址（最通用）
插件安装 https://github.com/nidie2580/demo-plugin.git

# 2. GitHub 短名（自动补全 github.com）
插件安装 nidie2580/demo-plugin

# 3. 仅插件名（从 nidie2580 命名空间查找）
插件安装 demo-plugin
```

### 🗑️ 卸载插件

```
插件卸载 demo-plugin
```

> 卸载时会自动备份为 `.bak.<时间戳>` 目录，1 分钟后自动清理。

### 🔄 更新插件

```bash
插件更新                  # 批量更新所有 Git 插件
插件更新 demo-plugin      # 单独更新指定插件
```

### 🔍 查看插件详情

```
插件信息 demo-plugin
```

显示：版本、作者、安装源、安装/更新时间、最近 5 条提交、能力标签（消息/HTTP/工作流/适配器/配置/Web面板）等。

### 🟢🔴 启用 / 禁用

```
插件禁用 demo-plugin     # 标记为禁用（重启生效）
插件启用 demo-plugin     # 重新启用
```

### 🔗 插件源管理

```
插件源列表                   # 列出所有源
插件源添加 我的源 https://github.com/xxx/yyy  个人源描述
插件源删除 我的源             # 删除指定源
```

### 🔎 插件搜索

```
插件搜索 关键词
```

## 📁 项目结构

```
nidie-plugin-manager/
├── index.js                         # 入口文件（自动加载 plugin/ 目录）
├── package.json                     # 插件元数据与依赖
├── .gitignore
├── plugin/
│   └── manager.js                   # 主插件类（继承 plugin 基类）
├── lib/
│   ├── store.js                     # 配置与状态持久化（sources / plugins）
│   ├── git-utils.js                 # git clone / pull / log 封装
│   └── plugin-utils.js              # 扫描、删除、命名校验等工具
├── commonconfig/
│   └── pm-defaults.js               # XRK CommonConfig 注册
└── data/
    ├── .gitkeep
    ├── sources.json                 # 插件源配置（首次运行生成）
    └── plugins.json                 # 安装/禁用状态（首次运行生成）
```

## 🔧 命令速查表

| 命令 | 说明 | 权限 |
|-----|------|------|
| `插件帮助` | 查看帮助 | all |
| `插件列表` | 已安装插件 | master |
| `插件安装 <地址>` | 安装新插件 | master |
| `插件卸载 <名称>` | 卸载插件 | master |
| `插件更新 [名称]` | 更新插件 | master |
| `插件信息 <名称>` | 查看详情 | master |
| `插件启用 <名称>` | 启用插件 | master |
| `插件禁用 <名称>` | 禁用插件 | master |
| `插件源列表` | 插件源列表 | master |
| `插件源添加 ...` | 添加插件源 | master |
| `插件源删除 <名>` | 删除插件源 | master |
| `插件搜索 <关键词>` | 搜索插件 | all |

## ⚠️ 注意事项

1. **需要 Git**：安装和更新插件依赖系统安装 `git` 命令
2. **权限控制**：安装、卸载、更新、源管理仅限主人（master）
3. **启用/禁用**：标记后需重启 XRK-Yunzai 才生效
4. **热重载**：新安装插件需重启机器人才能加载（除非框架支持热更）
5. **self-protection**：不允许卸载或禁用 `nidie-plugin-manager` 自身

## 🤝 适配说明

本插件针对 **XRK-Yunzai v3.2+** 开发，兼容其 `plugin` 基类：

- ESM 模块（`import/export`）
- 构造函数 `super({ name, dsc, event, priority, rule[] })`
- `rule.reg` 正则匹配 + `rule.fnc` 方法名
- `rule.permission`：`'all'` / `'master'`
- 运行时对象：`e.reply(msg)`、`e.msg`、`e.user_id`、`e.isMaster`
- 全局对象：`Bot`（读取 master 配置作为 fallback）

## 📄 协议

[MIT License](./LICENSE)

## 📌 项目仓库

https://github.com/nidie2580/nidie
