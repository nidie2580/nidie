import { readdirSync, statSync } from 'node:fs'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { dirname, join } from 'node:path'

const __filename = fileURLToPath(import.meta.url)
const __dirname = dirname(__filename)

const plugins = []
const pluginDir = join(__dirname, 'plugin')

try {
  const files = readdirSync(pluginDir).filter(f => f.endsWith('.js'))
  for (const file of files) {
    const mod = await import(pathToFileURL(join(pluginDir, file)).href)
    if (mod.default) {
      plugins.push(mod.default)
    } else {
      for (const key of Object.keys(mod)) {
        if (typeof mod[key] === 'function') {
          plugins.push(mod[key])
        }
      }
    }
  }
} catch (err) {
  console.error(`[nidie-plugin-manager] 加载 plugin/ 目录失败:`, err.message)
}

export default plugins
