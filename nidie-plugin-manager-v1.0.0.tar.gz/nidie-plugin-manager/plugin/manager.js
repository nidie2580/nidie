import { readFileSync, existsSync } from 'node:fs'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import {
  loadSources, addSource, removeSource,
  loadConfig, markInstalled, markUninstalled, markUpdated,
  setPluginDisabled, isPluginDisabled
} from '../lib/store.js'
import {
  gitClone, gitPull, gitCurrentCommit, gitLog,
  checkGitAvailable, runPnpmInstall,
  getPluginNameFromUrl, normalizeRepoUrl
} from '../lib/git-utils.js'
import {
  scanInstalledPlugins, getPluginInfo, removePluginDir,
  validatePluginName
} from '../lib/plugin-utils.js'

const __filename = fileURLToPath(import.meta.url)
const __dirname = dirname(__filename)
const SELF_DIR = resolve(__dirname, '..')
const PLUGINS_ROOT = resolve(SELF_DIR, '..')
const XRK_ROOT = resolve(PLUGINS_ROOT, '..')

const SELF_NAME = 'nidie-plugin-manager'

function isMaster(e) {
  if (e.isMaster) return true
  if (e.user_id && e.master && String(e.user_id) === String(e.master)) return true
  if (typeof Bot !== 'undefined' && Bot.config && Bot.config.master) {
    const masters = Array.isArray(Bot.config.master) ? Bot.config.master : [Bot.config.master]
    return masters.map(String).includes(String(e.user_id))
  }
  return false
}

function formatDate(iso) {
  if (!iso) return '未知'
  try {
    const d = new Date(iso)
    const pad = n => String(n).padStart(2, '0')
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`
  } catch {
    return iso
  }
}

export default class PluginManager extends plugin {
  constructor() {
    super({
      name: 'nidie插件管理器',
      dsc: '一键安装、更新、卸载、管理XRK-Yunzai插件',
      event: 'message',
      priority: 500,
      rule: [
        {
          reg: /^#?(插件|pm)\s*帮助$/i,
          fnc: 'showHelp',
          permission: 'all'
        },
        {
          reg: /^#?(插件|pm)\s*列表$/i,
          fnc: 'listPlugins',
          permission: 'master'
        },
        {
          reg: /^#?(插件|pm)\s*安装\s+(.+)$/i,
          fnc: 'installPlugin',
          permission: 'master'
        },
        {
          reg: /^#?(插件|pm)\s*卸载\s+([\w-_.]+)$/i,
          fnc: 'uninstallPlugin',
          permission: 'master'
        },
        {
          reg: /^#?(插件|pm)\s*更新(\s+[\w-_.]+)?$/i,
          fnc: 'updatePlugin',
          permission: 'master'
        },
        {
          reg: /^#?(插件|pm)\s*信息\s+([\w-_.]+)$/i,
          fnc: 'showPluginInfo',
          permission: 'master'
        },
        {
          reg: /^#?(插件|pm)\s*禁用\s+([\w-_.]+)$/i,
          fnc: 'disablePlugin',
          permission: 'master'
        },
        {
          reg: /^#?(插件|pm)\s*启用\s+([\w-_.]+)$/i,
          fnc: 'enablePlugin',
          permission: 'master'
        },
        {
          reg: /^#?(插件|pm)\s*源\s*列表$/i,
          fnc: 'listSources',
          permission: 'master'
        },
        {
          reg: /^#?(插件|pm)\s*源\s*添加\s+(\S+)\s+(\S+)(\s+.+)?$/i,
          fnc: 'addSourceCmd',
          permission: 'master'
        },
        {
          reg: /^#?(插件|pm)\s*源\s*删除\s+(\S+)$/i,
          fnc: 'removeSourceCmd',
          permission: 'master'
        },
        {
          reg: /^#?(插件|pm)\s*搜索\s+(.+)$/i,
          fnc: 'searchPlugins',
          permission: 'all'
        }
      ]
    })
  }

  async showHelp(e) {
    const lines = [
      '🧰 nidie 插件管理器 v1.0.0',
      '',
      '📋 命令列表（需主人权限，# 前缀可选）：',
      '',
      '  插件帮助           → 查看本帮助',
      '  插件列表           → 列出所有已安装插件',
      '  插件安装 <地址>    → 从 Git 仓库安装插件',
      '  插件卸载 <名称>    → 卸载指定插件',
      '  插件更新 [名称]    → 更新单个或全部插件',
      '  插件信息 <名称>    → 查看插件详情',
      '  插件启用/禁用 <名> → 启用或禁用插件',
      '  插件搜索 <关键词>  → 搜索可用插件',
      '',
      '🔗 插件源管理：',
      '  插件源列表         → 列出所有插件源',
      '  插件源添加 <名> <地址> [描述]',
      '  插件源删除 <名>    → 删除插件源',
      '',
      '💡 安装示例：',
      '  插件安装 https://github.com/nidie2580/demo-plugin',
      '  插件安装 nidie2580/demo-plugin',
      '  插件安装 demo-plugin',
      '',
      '📦 项目仓库：https://github.com/nidie2580/nidie'
    ]
    await e.reply(lines.join('\n'))
  }

  async listPlugins(e) {
    const installed = scanInstalledPlugins(XRK_ROOT)
    const store = loadConfig()
    if (!installed.length) {
      return e.reply('⚠️  未检测到任何插件。')
    }

    const lines = [`📦 已安装插件（共 ${installed.length} 个）：`, '']
    for (const p of installed) {
      const info = store.installed[p.name] || {}
      const disabled = store.disabled.includes(p.name) ? ' 🔴禁用' : ''
      const git = p.isGit ? ' [Git]' : ''
      const pkgVer = info.version || (info.package && info.package.version) || ''
      const verStr = pkgVer ? ` v${pkgVer}` : ''
      lines.push(`· ${p.name}${verStr}${git}${disabled}`)
      if (info.url) lines.push(`    📥 源: ${info.url}`)
      if (info.installedAt) lines.push(`    📅 安装: ${formatDate(info.installedAt)}`)
      if (info.dsc) lines.push(`    📝 ${info.dsc}`)
    }
    lines.push('', '提示：发送「插件信息 <名称>」查看详细信息')
    await e.reply(lines.join('\n'))
  }

  async installPlugin(e) {
    if (!isMaster(e)) return e.reply('❌ 仅主人可使用此命令')
    const raw = e.msg || e.message?.raw_message || ''
    const m = raw.match(/安装\s+(.+)$/i)
    if (!m) return e.reply('❌ 用法：插件安装 <仓库地址>')

    const input = m[1].trim()
    const normalized = normalizeRepoUrl(input)
    const pluginName = getPluginNameFromUrl(normalized || input)

    if (!validatePluginName(pluginName)) {
      return e.reply(`❌ 插件名「${pluginName}」不合法`)
    }

    const targetDir = join(PLUGINS_ROOT, pluginName)
    if (existsSync(targetDir)) {
      return e.reply(`❌ 插件「${pluginName}」已存在，如需重装请先卸载。`)
    }

    const gitOk = await checkGitAvailable()
    if (!gitOk) {
      return e.reply('❌ 系统未检测到 git 命令，请先安装 Git。')
    }

    await e.reply(`⬇️  正在安装「${pluginName}」...\n源: ${normalized}`)

    try {
      const cloneRes = await gitClone(normalized, targetDir)
      const commit = await gitCurrentCommit(targetDir)
      const logs = await gitLog(targetDir, 3)

      let pkgInfo = {}
      const pkgPath = join(targetDir, 'package.json')
      if (existsSync(pkgPath)) {
        try {
          pkgInfo = JSON.parse(readFileSync(pkgPath, 'utf-8'))
        } catch {}
      }

      let installRes = null
      if (existsSync(join(XRK_ROOT, 'pnpm-workspace.yaml'))) {
        await e.reply('📦 正在安装依赖 (pnpm)...')
        installRes = await runPnpmInstall(XRK_ROOT, pkgInfo.name || pluginName)
      }

      markInstalled(pluginName, {
        url: normalized,
        source: input,
        commit,
        version: pkgInfo.version || '',
        desc: pkgInfo.description || '',
        package: { name: pkgInfo.name, version: pkgInfo.version }
      })

      const lines = [
        `✅ 插件「${pluginName}」安装成功！`,
        '',
        `📥 源地址: ${normalized}`,
        `🔖 当前版本: ${commit || '未知'}`,
      ]
      if (pkgInfo.version) lines.push(`📦 包版本: v${pkgInfo.version}`)
      if (pkgInfo.description) lines.push(`📝 描述: ${pkgInfo.description}`)
      if (logs.length) {
        lines.push('', '📜 最近提交:')
        logs.forEach(l => lines.push(`  · ${l}`))
      }
      if (installRes) {
        lines.push('')
        lines.push(installRes.ok ? '✅ 依赖安装完成' : `⚠️  依赖安装可能失败: ${installRes.error?.slice(0, 100)}`)
      }
      lines.push('', '💡 若需加载此插件，请重启机器人或执行热重载。')
      await e.reply(lines.join('\n'))
    } catch (err) {
      await e.reply(`❌ 安装失败：${err.message}`)
    }
  }

  async uninstallPlugin(e) {
    if (!isMaster(e)) return e.reply('❌ 仅主人可使用此命令')
    const raw = e.msg || e.message?.raw_message || ''
    const m = raw.match(/卸载\s+([\w-_.]+)/i)
    if (!m) return e.reply('❌ 用法：插件卸载 <插件名称>')

    const name = m[1].trim()
    if (!validatePluginName(name)) {
      return e.reply(`❌ 插件名「${name}」不合法`)
    }
    if (name === SELF_NAME) {
      return e.reply('❌ 不能卸载插件管理器自身')
    }
    const targetDir = join(PLUGINS_ROOT, name)
    if (!existsSync(targetDir)) {
      return e.reply(`❌ 插件「${name}」不存在`)
    }

    try {
      const result = removePluginDir(XRK_ROOT, name)
      markUninstalled(name)
      await e.reply(
        `✅ 插件「${name}」已卸载（已备份至：\n${result.backup}，\n1分钟后自动清理）。\n请重启机器人以使变更生效。`
      )
    } catch (err) {
      await e.reply(`❌ 卸载失败：${err.message}`)
    }
  }

  async updatePlugin(e) {
    if (!isMaster(e)) return e.reply('❌ 仅主人可使用此命令')
    const raw = e.msg || e.message?.raw_message || ''
    const m = raw.match(/更新\s+([\w-_.]+)?/i)
    const targetName = m && m[1] ? m[1].trim() : null

    const all = scanInstalledPlugins(XRK_ROOT).filter(p => p.isGit && p.name !== SELF_NAME)

    if (targetName) {
      const target = all.find(p => p.name === targetName)
      if (!target) {
        return e.reply(`❌ 插件「${targetName}」不存在或不是 Git 安装的。`)
      }
      await this._doUpdate(e, target)
    } else {
      if (!all.length) {
        return e.reply('⚠️  没有可更新的 Git 插件。')
      }
      await e.reply(`🔄 正在批量更新 ${all.length} 个插件...`)
      const results = []
      for (const p of all) {
        try {
          const r = await this._doUpdate(e, p, true)
          results.push(r)
        } catch (err) {
          results.push({ name: p.name, ok: false, error: err.message })
        }
      }
      const lines = ['📊 批量更新结果：', '']
      for (const r of results) {
        lines.push(r.ok
          ? `✅ ${r.name}${r.updated ? '（已更新）' : '（已是最新）'}`
          : `❌ ${r.name}: ${r.error?.slice(0, 80)}`
        )
      }
      await e.reply(lines.join('\n'))
    }
  }

  async _doUpdate(e, p, silent = false) {
    if (!silent) await e.reply(`🔄 正在更新「${p.name}」...`)
    try {
      const before = await gitCurrentCommit(p.path)
      const res = await gitPull(p.path)
      const after = await gitCurrentCommit(p.path)
      markUpdated(p.name, after)
      if (res.updated) {
        const logs = await gitLog(p.path, 3)
        const lines = [
          `✅「${p.name}」更新成功！`,
          `  ${before || '?'} → ${after || '?'}`
        ]
        if (logs.length) {
          lines.push('📜 更新内容：')
          logs.forEach(l => lines.push(`  · ${l}`))
        }
        if (!silent) await e.reply(lines.join('\n'))
        return { name: p.name, ok: true, updated: true, commit: after }
      } else {
        if (!silent) await e.reply(`✅「${p.name}」已是最新版本。`)
        return { name: p.name, ok: true, updated: false, commit: after }
      }
    } catch (err) {
      if (!silent) await e.reply(`❌「${p.name}」更新失败：${err.message}`)
      return { name: p.name, ok: false, error: err.message }
    }
  }

  async showPluginInfo(e) {
    const raw = e.msg || e.message?.raw_message || ''
    const m = raw.match(/信息\s+([\w-_.]+)/i)
    if (!m) return e.reply('❌ 用法：插件信息 <名称>')
    const name = m[1].trim()
    const info = getPluginInfo(XRK_ROOT, name)
    if (!info) return e.reply(`❌ 插件「${name}」不存在`)
    const store = loadConfig()
    const meta = store.installed[name] || {}
    const disabled = store.disabled.includes(name)

    const lines = [`🔍 插件详情：${name}${disabled ? '（已禁用）' : ''}`, '']
    lines.push(`📍 路径: ${info.path}`)
    if (info.package) {
      lines.push(`📦 包名: ${info.package.name || '-'}`)
      lines.push(`🏷️  版本: ${info.package.version || '-'}`)
      if (info.package.description) lines.push(`📝 描述: ${info.package.description}`)
      if (info.package.author) lines.push(`👤 作者: ${typeof info.package.author === 'string' ? info.package.author : (info.package.author.name || '-')}`)
      if (info.package.license) lines.push(`📄 协议: ${info.package.license}`)
    }
    if (meta.url) lines.push(`📥 安装源: ${meta.url}`)
    if (meta.installedAt) lines.push(`📅 安装时间: ${formatDate(meta.installedAt)}`)
    if (meta.updatedAt) lines.push(`🔄 最近更新: ${formatDate(meta.updatedAt)}`)
    if (meta.commit) lines.push(`🔖 提交: ${meta.commit}`)

    if (info.isGit) {
      const commit = await gitCurrentCommit(info.path)
      const logs = await gitLog(info.path, 5)
      if (commit) lines.push(`🔖 当前提交: ${commit}`)
      if (logs.length) {
        lines.push('', '📜 最近提交记录：')
        logs.forEach(l => lines.push(`  · ${l}`))
      }
    }

    const subdirs = info.files.filter(f => f.type === 'dir').map(f => f.name)
    if (subdirs.length) {
      lines.push('', `📂 子目录: ${subdirs.join(', ')}`)
    }
    const features = []
    if (subdirs.includes('plugin')) features.push('消息命令')
    if (subdirs.includes('events')) features.push('系统事件')
    if (subdirs.includes('http')) features.push('HTTP API')
    if (subdirs.includes('workflow')) features.push('AI 工作流')
    if (subdirs.includes('adapter')) features.push('协议适配器')
    if (subdirs.includes('commonconfig')) features.push('公共配置')
    if (subdirs.includes('www')) features.push('Web 面板')
    if (features.length) lines.push(`🎯 能力: ${features.join(' / ')}`)

    await e.reply(lines.join('\n'))
  }

  async disablePlugin(e) {
    if (!isMaster(e)) return e.reply('❌ 仅主人可使用此命令')
    const raw = e.msg || e.message?.raw_message || ''
    const m = raw.match(/禁用\s+([\w-_.]+)/i)
    if (!m) return e.reply('❌ 用法：插件禁用 <名称>')
    const name = m[1].trim()
    if (name === SELF_NAME) return e.reply('❌ 不能禁用插件管理器自身')
    if (!existsSync(join(PLUGINS_ROOT, name))) return e.reply(`❌ 插件「${name}」不存在`)
    if (isPluginDisabled(name)) return e.reply(`⚠️  「${name}」已是禁用状态`)
    setPluginDisabled(name, true)
    await e.reply(`🔴 已标记「${name}」为禁用状态（重启后生效）。`)
  }

  async enablePlugin(e) {
    if (!isMaster(e)) return e.reply('❌ 仅主人可使用此命令')
    const raw = e.msg || e.message?.raw_message || ''
    const m = raw.match(/启用\s+([\w-_.]+)/i)
    if (!m) return e.reply('❌ 用法：插件启用 <名称>')
    const name = m[1].trim()
    if (!existsSync(join(PLUGINS_ROOT, name))) return e.reply(`❌ 插件「${name}」不存在`)
    if (!isPluginDisabled(name)) return e.reply(`⚠️  「${name}」已是启用状态`)
    setPluginDisabled(name, false)
    await e.reply(`🟢 已标记「${name}」为启用状态（重启后生效）。`)
  }

  async listSources(e) {
    const sources = loadSources()
    const lines = [`🔗 插件源列表（共 ${sources.length} 个）：`, '']
    sources.forEach((s, i) => {
      lines.push(`${i + 1}. ${s.name}`)
      lines.push(`   📥 ${s.url}`)
      if (s.desc) lines.push(`   📝 ${s.desc}`)
      lines.push('')
    })
    lines.push('提示：使用「插件源添加 <名称> <地址> [描述]」添加源。')
    await e.reply(lines.join('\n'))
  }

  async addSourceCmd(e) {
    if (!isMaster(e)) return e.reply('❌ 仅主人可使用此命令')
    const raw = e.msg || e.message?.raw_message || ''
    const m = raw.match(/源\s*添加\s+(\S+)\s+(\S+)(?:\s+(.+))?/i)
    if (!m) return e.reply('❌ 用法：插件源添加 <名称> <地址> [描述]')
    const [, name, url, desc] = m
    try {
      addSource(name, url, desc || '')
      await e.reply(`✅ 插件源「${name}」已添加。`)
    } catch (err) {
      await e.reply(`❌ 添加失败：${err.message}`)
    }
  }

  async removeSourceCmd(e) {
    if (!isMaster(e)) return e.reply('❌ 仅主人可使用此命令')
    const raw = e.msg || e.message?.raw_message || ''
    const m = raw.match(/源\s*删除\s+(\S+)/i)
    if (!m) return e.reply('❌ 用法：插件源删除 <名称>')
    const name = m[1].trim()
    try {
      removeSource(name)
      await e.reply(`✅ 插件源「${name}」已删除。`)
    } catch (err) {
      await e.reply(`❌ 删除失败：${err.message}`)
    }
  }

  async searchPlugins(e) {
    const raw = e.msg || e.message?.raw_message || ''
    const m = raw.match(/搜索\s+(.+)$/i)
    if (!m) return e.reply('❌ 用法：插件搜索 <关键词>')
    const kw = m[1].trim().toLowerCase()
    const sources = loadSources()
    const installed = new Set(scanInstalledPlugins(XRK_ROOT).map(p => p.name))
    const store = loadConfig()

    const localHits = []
    for (const [name, info] of Object.entries(store.installed)) {
      const hay = `${name} ${info.desc || ''} ${info.url || ''}`.toLowerCase()
      if (hay.includes(kw)) localHits.push({ name, info, source: '本地记录' })
    }

    const lines = [
      `🔍 插件搜索：${kw}`,
      '',
      '📌 说明：插件管理器支持直接从 Git 地址安装，',
      '      发送「插件安装 <仓库地址>」即可。',
      ''
    ]

    if (localHits.length) {
      lines.push('📂 本地安装记录命中：')
      for (const h of localHits) {
        lines.push(`· ${h.name}${installed.has(h.name) ? ' ✅已装' : ''}`)
        if (h.info.dsc) lines.push(`  📝 ${h.info.dsc}`)
        if (h.info.url) lines.push(`  📥 ${h.info.url}`)
      }
      lines.push('')
    }

    lines.push('🔗 已配置插件源：')
    sources.forEach(s => {
      lines.push(`· ${s.name} - ${s.url}`)
      if (s.desc) lines.push(`  📝 ${s.desc}`)
    })
    lines.push('')
    lines.push('💡 可在 GitHub/Gitee 搜索 yunzai plugin 关键词发现更多插件。')

    await e.reply(lines.join('\n'))
  }
}
